import 'package:flutter/material.dart';
import 'api_functions.dart'; // Make sure this file contains your API functions

class QueryData extends StatefulWidget {
  const QueryData({super.key});

  @override
  State<QueryData> createState() => _QueryDataPageState();
}

class _QueryDataPageState extends State<QueryData> {
  // Define a Future object to handle results from the async function
  Future<String>? futureFetchResult;

  // Define controller objects to handle user input datetime from UI text field widgets
  final TextEditingController _controller_startDate = TextEditingController();
  final TextEditingController _controller_endDate = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Set default datetime to simplify test (start and end date range).
    _controller_startDate.text = '2025-02-23'; // Default start date
    _controller_endDate.text = '2025-02-25';   // Default end date
  }

  @override
  void dispose() {
    // Clean up the controllers when the widget is disposed.
    _controller_startDate.dispose();
    _controller_endDate.dispose();
    super.dispose();
  }

  // This function will be executed when the "Fetch Data" button is pressed.
  void _fetchHeartRateData() {
    // Call async function to fetch data using start and end date
    final String startDate = _controller_startDate.text;
    final String endDate = _controller_endDate.text;

    futureFetchResult = getHeartRate(startDate, endDate);  // Call your API function here

    // Refresh page to show fetched data results.
    setState(() {
      build(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fetch Heart Rate Data')),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 110.0),
            ),
            // Text Fields: Input start and end date for heart rate data range
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15),
              child: TextField(
                controller: _controller_startDate,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Start Date (YYYY-MM-DD)',
                  hintText: 'Enter start date',
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              child: TextField(
                controller: _controller_endDate,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'End Date (YYYY-MM-DD)',
                  hintText: 'Enter end date',
                ),
              ),
            ),
            // Button: Fetch Heart Rate Data button
            SizedBox(
              height: 65,
              width: 360,
              child: Padding(
                padding: const EdgeInsets.only(top: 20.0),
                child: ElevatedButton(
                  child: const Text(
                    'Fetch Heart Rate Data',
                    style: TextStyle(color: Color.fromARGB(255, 3, 59, 105), fontSize: 20),
                  ),
                  onPressed: _fetchHeartRateData,  // Fetch data when button is pressed
                ),
              ),
            ),
            // Container: Show fetched data on screen
            Container(
              margin: const EdgeInsets.all(20),
              padding: const EdgeInsets.all(20),
              child: buildFutureBuilder(),
            ),
          ],
        ),
      ),
    );
  }

  // This function will build the widget to show fetched data on the screen
  FutureBuilder<String> buildFutureBuilder() {
    return FutureBuilder<String>(
      future: futureFetchResult,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          // Display the fetched data when data is available
          return Center(child: Text(snapshot.data!));  // Display data
        } else if (snapshot.hasError) {
          // Display an error message if there's an error
          return Text('${snapshot.error}');
        } else {
          // Display a loading indicator while waiting for data
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }
}
